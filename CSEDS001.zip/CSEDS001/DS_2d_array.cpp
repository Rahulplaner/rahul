#include<stdio.h>
int main()
{
	int mark[3][3]={{2,3,4},{2,4,8},{3,7,7}};
	printf("%d ",mark[0][0]);
	printf("%d ",mark[0][1]);
	printf("%d \n",mark[0][2]);
	printf("%d ",mark[1][0]);
	printf("%d ",mark[1][1]);
	printf("%d \n",mark[1][2]);
	printf("%d ",mark[2][0]);
	printf("%d ",mark[2][1]);
	printf("%d ",mark[2][2]);
	return 0;
}
