#include<stdio.h>
int main()
{
	int i;
	for(i=1;i<=15;i++)
	{
		printf("%d rahul kans behera\n", i);
}
	return 0;
}
