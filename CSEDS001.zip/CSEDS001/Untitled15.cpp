#include<stdio.h>
main()
{
	char x;
	printf("Enter caracter X :");
	scanf("%c",x);
	if(islower(x))
	{
		printf("X is in lowercase");
	}
	else 
	{
		printf("X is not lowercase"); 
	}
	return 0;
}
