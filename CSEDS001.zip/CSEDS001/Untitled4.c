#include<stdio.h>
int main(){

	int i,n,c=0;
	printf("Enter the number:");
	scanf("%d", &n);
	for(i=2;i<=n;i++)
	{
	if(n%i==0)
		c++;
    }
    if(c==0)
    	printf(" it is prime number");
    else
    	("not a prime number");
	return 0;
}
