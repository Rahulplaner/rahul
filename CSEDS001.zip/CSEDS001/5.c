#include<stdio.h>
int main()
{
	int x,y,z;
	printf("Enter  First Number : ");
	scanf("%d",&x);
	printf("Enter Second Number : ");
	scanf("%d", &y);
	printf("Value of x=%d\n",x);
	printf("Value of y=%d\n",y);
	z=x+y;
	printf("Value of z=%d\n",z);
	return 0;
}
	

