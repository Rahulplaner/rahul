#include<stdio.h>
int main()
{ 
    float p,t,r,Si;
    printf("Enter the principle amount");
    scanf("%f",&p);
    printf("Enter the time in year");
    scanf("%f",&t);
    printf("Enter the rate of uintrest ");
    scanf("%f",&r);
    Si=(r*p*t)/100;
    printf("enter the amount of intrest%f",Si);
    return 0;
}
