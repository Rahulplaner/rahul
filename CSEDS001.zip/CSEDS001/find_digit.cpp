	#include<stdio.h>
int main(){
	int n,c=0;
    printf("Enter number");
    scanf("%d",&n);
    while(n != 0){
    	
    	c++; 
		n =n/10;       
	}
	printf("Number of digit are %d", c);
	return 0; 
}
