
#include<stdio.h>
int main()
{
	printf("This is the example of escape sequence character\n");
	printf("NAME \"Rahul kans behera\"\n");
	printf("Roll no CSEDS001\b");
	scanf("%d");
	return 0;
} 
