#include<stdio.h>
int main()
{
	int x;
	printf("Enter the digit(0 to 6):");
	scanf("%d",&x);
	if(x==0)
	{
		printf("Sunday\n");
	}
	else if(x==1)
		{
		printf("Monday\n");
	}
	else if(x==2)
	{
		printf("Tuesday\n");
	}
	else if(x==3)
	{
		printf("Wednesday\n");
	}
	else if(x==4)
	{
		printf("Thursday\n");
	}
	else if(x==5)
	{
		printf("Friday\n");
	}
	else if(x==6)
	{
		printf("Saturday\n");
	}
	
	else
	{
		printf("Invalid input! Please put a valid digit between 0-6");
	}
	
	
	
	return 0;
}
