#include<stdio.h>
int main()
{
	int x,y;
	printf("Enter Number : ");
	scanf("%d", &x);
	printf("Enter Number : ");
	scanf("%d", &x);
	printf("Value of x=%d\n",x);
	printf("Value of y=%d\n",y);
	return 0;
}


