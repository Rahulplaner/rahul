#include<stdio.h>
int main(){
	int row, col;
	int i, j;
	printf(" Enter the no of row and col : \n");
	scanf("%d %d", &row ,&col);
	int arr[row][col];
	printf("Enter the element of the matrix :\n");
	for(i=0; i<row; i++){
	
    for(j=0; j<col; j++){
	scanf("%d", &arr[i][j]);
	
    }
}
int max=arr[0][0];
for(i=0; i<row; i++){
	for(j=0; j<col; j++){
		if(arr[i][j]>max)
		max = arr[i][j];
	}
}

	printf("largest element is %d\n" , max);
	return 0;
}
