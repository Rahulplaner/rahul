#include<stdio.h>
int main()
{
	int r1, c1, r2, c2, i, j, k;
	printf("Enter row and column size of 1st matrix matrix");
	scanf("%d%d", &r1, &c1);
	int matrix1[r1][c1];
	printf("Enter matrix1 elements:\n");
	for(i=0; i<r1; i++){
	    for(j=0; j<c1; j++){	
	        scanf("%d",&matrix1[i][j]);
	    }		
	}
	printf("Enter row and column size of 2nd matrix matrix");
	scanf("%d%d", &r2, &c2);
	int matrix2[r2][c2];
	printf("Enter matrix2 elements:\n");
	for(i=0; i<r2; i++){
	    for(j=0; j<c2; j++){	
	        scanf("%d",&matrix2[i][j]);
	    }		
	}
	if(c1==r2)
	{
		int result[r1][c2];
		for(i=0; i<r1; i++){
			for(j=0; j<c2; j++){
				int sum = 0;
				for(k=0; k<r1; k++){
					sum += matrix1[i][k] * matrix2[k][j];
				}
			    result[i][j] = sum;
			    printf("%d ", result[i][j]);
	        }
	        printf("\n");
		}
	}
	else
	    printf("Column size of 1st matrix is not equak to row size of 2nd matrix ");
	return 0;
}
