#include<stdio.h>
int main()
{
	int a,b,c;
	printf("Enter the value of a,b,and c");
	scanf("%d%d%d",&a, &b,&c);
	switch(a>b && a>c)
	{
		case 1:
			printf("%d is largest",a);
			break;

	    case 0:
	    	switch(b>c){
	        	case 1:
	        		printf("%d is largest", b);
	        		break;
	        	case 0:
	        		printf("%d is largest",c);
			        break;
			}
     }
	return 0;
}
