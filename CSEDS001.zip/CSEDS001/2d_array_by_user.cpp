#include<stdio.h>
int main()
{
	int marks[3][2];
	int i,j;
	printf(" Enter Array elements are : \n");
	for(i=0; i<3; i++){
		for(j=0; j<2; j++){
		scanf("%d", &marks[i][j]);
		}
	}
	printf("Array elements are : \n");
	for(i=0; i<3; i++){
		for(j=0; j<2; j++){
			printf("%d ",marks[i][j]);
		}
		printf("\n");
	}
	return 0;
}
