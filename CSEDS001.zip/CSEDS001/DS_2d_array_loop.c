#include<stdio.h>
int main()
{
	int marks[3][2]={{1,2},{3,4},{5,6}};
	int i,j;
	printf("Array elements are : \n");
	for(i=0; i<3; i++)
	{
		for(j=0; j<2; j++)
		{
			printf("%d ",marks[j][i]);
		}
		printf("\n");
	}
	return 0;
}
