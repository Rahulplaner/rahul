#include<stdio.h>
int main()
{
	int r, c;
	printf("Enter row and column size of  matrix");
	scanf("%d%d", &r, &c);
	int matrix1[r][c], matrix2[r][c], sum[r][c], i, j;
	printf("Enter matrix1 elements:\n");
	for(i=0; i<r; i++){
	    for(j=0; j<c; j++){	
	        scanf("%d",&matrix1[i][j]);
	    }		
	}
	printf("Enter matrix2 elements:\n");
		for(i=0; i<r; i++){
	    for(j=0; j<c; j++){	
	        scanf("%d",&matrix2[i][j]);
	    }		
	}
	printf("Addition of matrix is :\n");
		for(i=0; i<r; i++){
	    for(j=0; j<c; j++){	
	        sum[i][j] = matrix1[i][j] + matrix2[i][j];
	        printf("%d ", sum[i][j]);
	    }
		printf("\n");	
	}
	
	return 0;
}
