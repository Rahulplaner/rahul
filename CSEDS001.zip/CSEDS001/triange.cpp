#include<stdio.h>
#include<math.h>
int  main()
{
	int a,b,c,s,ar;
	printf("Enter the value of a=");
	scanf("%i",&a);
	printf("Enter the value of b=");
	scanf("%i",&b);
	printf("Enter the value of c=");
	scanf("%i",&c);
	s=(a+b+c)/2;
	ar=sqrt(s*(s-a)*(s-b)*(s-c));
	printf("\nar of the triangle = %i5 sq. units", ar);
    return 0; 
}
