#include<stdio.h>
int main(){
	int row, col,  sum=0;
	int i, j;
	printf(" Enter the no of row and col : \n");
	scanf("%d %d", &row ,&col);
	int matrix[row][col];
	printf("Enter the element of the matrix :\n");
	for(i=0; i<row; i++){
	
    for(j=0; j<col; j++){
	scanf("%d", &matrix[i][j]);
	sum += matrix[i][j];
    }
}
	printf("sum of all element in the matrix = %d\n" , sum);
	return 0;
}
