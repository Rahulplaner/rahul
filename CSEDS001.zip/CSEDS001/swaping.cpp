
#include<stdio.h>
int  main()
{
	int a,b,c;
	printf("Enter the number of a:");
	scanf("%i",&a);
	printf("Enter the number of b:");
	scanf("%i",&b);
    c=a;
    a=b;
    b=c;
    printf("the value of a%i \nb%i",a,b);
    return 0;
    
}
