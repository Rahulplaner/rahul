#include<stdio.h>
int main(){
	char ch='A';
	int x=456;
	float y=123.143;
	double z = 23.423256;
	printf("%c\n",ch);
	printf("%d\n",x);
	printf("%f\n",y);
	return 0;
}
