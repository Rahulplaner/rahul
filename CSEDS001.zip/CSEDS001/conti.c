#include<stdio.h>
int main()
{
	float sum=1,n,x, sign=-1;
	int i,j;
	printf("Enter the value of x");
	scanf("%f", &x);
	printf("Enter the value of n");
	scanf("%f", &n);
	for(i=2; i<=n; i++){
		float p= pow(x,i);
		float fact =1;
		for(j=1; j<=i; j++){
			fact = fact * j;
	}
    float res = p/fact;
    sum =sum + sign*res;
    if(sign == -1)
       sign = 1;
       else
       sign = -1;
}
	printf("Sum of series =%f", sum);
	return 0;
}
