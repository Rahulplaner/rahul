#include<stdio.h>
main()
{
	char manvi=10,shyam=9,william=8;
	
	
	if(manvi>shyam)
	{ if(manvi>william)
		printf("manvi is most experience");
		else{
		printf("william is most experienced");
	}
	}
	else 
	{
		if(shyam>william)
			{
				printf("shyam is most experienced");
			}
		else
			{
				printf("william is most experienced");
			} 
	}
	
	return 0;
}
