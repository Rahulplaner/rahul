#include<stdio.h>
int main()
{
	int num;
	printf("Enter Number :");
	scanf("%d",&num);
	if(num%2)
	{
		printf("The number is even ");
	}
	else 
	{
		printf("The number is odd "); 
	}
	return 0;
}

