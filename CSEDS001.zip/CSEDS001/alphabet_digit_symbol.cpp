#include<stdio.h>
main()
{
	char x;
	printf("Enter caracter X :");
	scanf("%c",&x);
	if(x>=48&&x<=57)
	{
		printf("X is a Digit");
	}
	else if((x>=65&&x<=90)||(x>=97&&x<=122))
	{
		printf("X is alphabet"); 
	}
	else
	{
		printf("X is Symbol");
	}
	return 0;
}
