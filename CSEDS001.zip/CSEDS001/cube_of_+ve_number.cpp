//WAP to read a number from a user and if input number is +ve then print the cube of that number.
#include<stdio.h>
int main()
{
	int num;
	printf("Enter Number :");
	scanf("%d",&num);
	if(num>0)
	{
		printf("cube of your number %d",num*num*num);
	}
	else
	{
		printf("number is not +ve number");
	}
	return 0;
}
