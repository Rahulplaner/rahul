#include<stdio.h>
int main(){
	int n,a=0;
    printf("Enter number");
    scanf("%d",&n);
    while(n != 0){
    	int rem = n%10;
    	printf("%d", rem);
    	a=a+rem;
    	n=n/10;       
	}
	printf("sum of sall digit is %d",a);
	return 0; 
}
