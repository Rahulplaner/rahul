#include<stdio.h>
int main()
{
	float a,b,c;
	printf("Enter Radius of Circle");
	scanf("%f",&a);
	
	b=2*3.141*a;
	
	c=3.141*a*a;
	printf("The Radius is%f\n The Area is%f\n The Perimeter%f",a,c,b);
	return 0;
}
