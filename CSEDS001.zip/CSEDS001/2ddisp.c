#include<stdio.h>
int main()
{
	int row,col;
	printf("enter row and column size: ");
	scanf("%d %d",&row, &col);
	int marks[row][col];
	int i,j;
	printf("enter array elements are: \n");
	for(i=0; i<row; i++)
	{
		for(j=0; j<col; j++)
		{
			scanf("%d", &marks[i][j]);
		}
		
	
}
printf("elements are:");
return 0;
} 
