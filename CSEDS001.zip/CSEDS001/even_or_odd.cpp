//wap to check given number is even or odd using opeator
#include <stdio.h>
int main()
{
	int x;
    printf("Enter the value of x ");
	scanf("%d",&x);
	(x%2==0)?printf("number is even"):printf("number is odd ") ;
}
