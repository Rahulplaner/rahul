#include<stdio.h>
int main()
{
	int x,y;
	printf("Enter Number :");
	scanf("%d",&x);
		printf("Enter Number :");
	scanf("%d",&y);
	if(x>y)
	{
		printf("Greatest number is x= %d",x);
	}
	else 
	{
		printf("Greatest number is y= %d",y); 
	}
	return 0;
}
