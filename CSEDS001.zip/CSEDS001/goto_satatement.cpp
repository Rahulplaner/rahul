#include<stdio.h>
int main()
{
	int num, sum=0;
	xyz:
	do{
		printf("Enter number ");
		scanf("%d", &num);
		sum += num    ;
	}while(num != 0);
	printf("sum =%d", sum);
	goto xyz;
	
	
	return 0;
}
