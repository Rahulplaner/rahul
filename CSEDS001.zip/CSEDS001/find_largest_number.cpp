#include<stdio.h>
int main()
{
	 int x,y;
	 printf("Enter the number of x and y");
	 scanf("%d%d",&x,&y);
	 int res =(x>y) ? x:y;
	 printf("largest number is %d", res);
	 return 0;
}

