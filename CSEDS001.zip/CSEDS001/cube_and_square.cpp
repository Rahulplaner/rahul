#include<stdio.h>
int main()
{
	int num;
	printf("Enter Number :");
	scanf("%d",&num);
	if(num>0)
	{
		printf("cube of your number %d",num*num*num);
	}
	else 
	{
		printf("square of %d",num*num); 
	}
	return 0;
}
