#include<stdio.h>
int main()
{
	int num;
	printf("Enter Number :");
	scanf("%d",&num);
	if(num>0)
	{
		printf("The number is +ve");
	}
	else if(num<0)
	{
		printf("The nnumber is -ve"); 
	}
	else
	{
		printf("NUMBER IS 0");
	}
	return 0;
}
