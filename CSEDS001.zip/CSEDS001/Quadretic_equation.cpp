#include<stdio.h>
#include<math.h>
int main()
{ 
    int a,b,c,d;
    printf("Enter the co-efficient a,b,c");
    scanf("%d%d%d",&a,&b,&c);
    d=b*b-4*a*c;
    if(d>0)
	{ 
	int root1 =(-b+sqrt(d))/(2*a);
	int root2 =(-b-sqrt(d))/(2*a);
	printf("Root 1=%d\n",root1);
	printf("Root 2=%d\n",root2);
}
else if (d==0)
{
	printf("Both the root are same :\n");
	int root= -b/(2*a);
	printf("root= %d\n",root);       
}
else 
{
	printf("Root is complex number : \n");
	int real =-b/(2*a);
	int img =sqrt(-d)/(2*a);
	printf("Root =%d+%di",real, img);
}
return 0;
}
