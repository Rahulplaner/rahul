#include <stdio.h>
#include <ctype.h> 

int main() {    
    char x;
    printf("Enter character X : "); 
    scanf(" %c", &x);             
    
    if(islower(x)) {
        printf("X is in lowercase");
    } else {
        printf("X is not lowercase");
    }
    return 0;
}
