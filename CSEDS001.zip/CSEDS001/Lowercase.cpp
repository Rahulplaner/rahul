#include<stdio.h>
main()
{
	char x;
	printf("Enter caracter X :");
	scanf("%c", &x);
	if(x>=97&&x<=122)
	{
		printf("X is in lowercase");
	}
	else 
	{
		printf("X is not lowercase"); 
	}
	return 0;
}
