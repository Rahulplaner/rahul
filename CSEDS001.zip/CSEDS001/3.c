# include<stdio.h>
int main()
{  
    char ch;
    int x= 345;
    float y=56.89;
    double z=56.345;
    printf("entre character: ");
    scanf("%c", &ch);
    printf(" value of z=%lf\n value of y=%f\n value of x= %d\n value of ch= %ch\n",z,y,x,ch);                        
    printf("%c", ch);
    return 0;
}
