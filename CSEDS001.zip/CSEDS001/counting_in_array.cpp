//WAP to find the largest  and smallest element in an array
#include<stdio.h>
int main()
{
	int n; //yaha pe maine n diclare kiya hai to store array size
    printf("Enter array size ");
    scanf("%d", &n);  // here i  read the size of array from user
    int arr[n], i , val;
    printf("Enter array element :");
    for(i=0; i<n; i++){
    	scanf("%d", &arr[i]);
    }
    printf("Enter element which you want to count");
    scanf("%d", &val);
    int count =0;
    for(i=0; i<n; i++){
    	if(arr[i]==val)
    	count++;
	}
	printf("%d occurs %d times", val, count);
    return 0;
}
