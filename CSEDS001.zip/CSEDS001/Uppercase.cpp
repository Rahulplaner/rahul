#include<stdio.h>
main()
{
	char x;
	printf("Enter caracter X :");
	scanf("%c", &x);
	if(x>=65&&x<=90)
	{
		printf("X is in Uppercase");
	}
	else 
	{
		printf("X is not Uppercase"); 
	}
	return 0;
}
