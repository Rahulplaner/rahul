//WAP to search a given element in an array
int main() {
	int n;
    
    printf("Enter the array size: ");
    scanf("%d", &n);
    int arr[n],val, i;
    printf("Enter ")
    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    for (i = 0; i < n; i++) {
        arr1[i] = arr[i];
    }
    

    return 0;
    
}
