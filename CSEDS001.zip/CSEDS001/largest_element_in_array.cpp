//WAP to find the largest element in an array
#include<stdio.h>
int main()
{
	int n; //yaha pe maine n diclare kiya hai to store array size
    printf("Enter array size ");
    scanf("%d", &n);  // here i  read the size of array from user
    int arr[n], i;
    printf("Enter array element :");
    for(i=0; i<n; i++){
    	scanf("%d", &arr[i]);
    }
   int max = arr[0];
   for(i=1; i<n; i++)
        {
        	if(arr[i]>max)
        	max = arr[i];
        	
		}
		printf("largest element is %d", max);
    return 0;
}
