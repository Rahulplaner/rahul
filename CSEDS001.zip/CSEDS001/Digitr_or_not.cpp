#include<stdio.h>
main()
{
	char x;
	printf("Enter caracter X :");
	scanf("%c",&x);
	if(x>=48&&x<=57)
	{
		printf("X is a Digit");
	}
	else 
	{
		printf("X is not Digit"); 
	}
	return 0;
}
