#include<stdio.h>
main()
{
	char x;
	printf("Enter caracter X :");
	scanf("%c",&x);
	if(x=='a'||x=='e'||x=='i'||x=='o'||x=='u'||x=='A'||x=='E'||x=='I'||x=='O'||x=='U')
	{
		printf("X is vowel");
	}
	else 
	{
		printf("X is consonant"); 
	}
	return 0;
}
