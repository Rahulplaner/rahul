#include<stdio.h>
int main()
{
	int x,y,z;
	printf("Enter Number :");
	scanf("%d",&x);
		printf("Enter Number :");
	scanf("%d",&y);
		printf("Enter Number :");
	scanf("%d",&z);
	if(x>y)
	{
		printf("Greatest number is x= %d",x);
	}
	else if(y>z)
	{
		printf("Greatest number is y= %d",y); 
	}
	else
	{
		printf("Greatest number is z= %d",z); 
	}
	return 0;
}
