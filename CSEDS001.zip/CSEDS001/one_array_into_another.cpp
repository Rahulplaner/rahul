//wap to copy the element of one arryay into another and display the copy array.
#include <stdio.h>

int main() {
	int n=5;
    int  arr[n], arr1[n], i;
    printf("Enter the array elements: ");
    
    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    for (i = 0; i < n; i++) {
        arr1[i] = arr[i];
    }
    printf(" elements of Copied array is:\n");
    for (i = 0; i < n; i++) {
        printf("%d ", arr1[i]);
    }

    return 0;
    
}
