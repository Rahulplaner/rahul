#include<stdio.h>
int main()
{
	
	int row,col;
	printf("enter 2d array element :");
	scanf("%d", &row ,&col);
	int i,j,marks[row][col];
	printf(" Enter Array elements are : \n");  //mistake in this program
	for(i=0; i<row; i++)
	{
		for(j=0; j<col; j++){
		scanf("%d", &marks[i][j]);
		}
	}
	printf("Array elements are : \n");
	for(i=0; i<row; i++){
		for(j=0; j<col; j++){
			printf("%d ",marks[i][j]);
		}
		printf("\n");
	}
	return 0;
}
