//WAP to search given element in an array
#include<stdio.h>
int main()
{
	int n; //yaha pe maine n diclare kiya hai to store array size
    printf("Enter array size ");
    scanf("%d", &n);  // here i  read the size of array from user
    int arr[n], i, val;
    printf("Enter array element :");
    for(i=0; i<n; i++){
    	scanf("%d", &arr[i]);
    }
    printf("Enter searching element ");
    scanf("%d", &val);
    //logic of searching
    int flag=0;
    for(i=0; i<n; i++){
    	if(arr[i]==val){// yaha pe main array ki value ko searching element se compare kar raha hoon
		
            flag =1;
        }
	}
	if(flag == 1)
	   printf("found !!!");
   	else
       printf(" not found !!!");
    return 0;
}
