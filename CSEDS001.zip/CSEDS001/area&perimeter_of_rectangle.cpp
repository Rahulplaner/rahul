#include<stdio.h>
int main()
{
	float a,b,c,d;
	printf("Enter Lenth of The Rectangle");
	scanf("%f",&a);
	printf("Enter Breadth of The Rectangle");
	scanf("%f",&b);
	c=2*(a+b);
	d=a*b;
	printf("The Length  is%f\n The breadth is%f\n The Area is%f\n The Perimeter is%f",a,b,d,c);
	return 0;
}
