//WAP to find the sum of all elements of an array
#include <stdio.h>

int main()
{
    int n;
    printf("Enter array size ");
    scanf("%d", &n);
    int arr[n], sum = 0, i;
    printf("Enter array element :");
    for(i=0; i<n; i++){
    	scanf("%d", &arr[i]);
	}
	 for(i=0; i<n; i++){
        sum = sum + arr[i];
    }
    printf("sum = %d", sum);
    return 0;
}

